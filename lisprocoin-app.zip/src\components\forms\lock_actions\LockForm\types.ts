export enum LockType {
  CREATE_LOCK = 'createLock',
  EXTEND_LOCK = 'extendLock',
  INCREASE_LOCK = 'increaseLock',
}
