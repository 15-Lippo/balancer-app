export const GWEI_UNIT = 1e9;
