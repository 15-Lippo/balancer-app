export enum FiatCurrency {
  usd = 'usd',
}

export enum FiatSymbol {
  usd = '$',
}

export const SUPPORTED_FIAT = [FiatCurrency.usd];
