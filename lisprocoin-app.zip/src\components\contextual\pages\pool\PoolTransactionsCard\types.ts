export enum PoolTransactionsTab {
  ALL_ACTIVITY = 'allActivity',
  USER_ACTIVITY = 'userActivity',
  SWAPS = 'swaps',
}
