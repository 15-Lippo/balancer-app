import { version } from '../../package.json';

export default function useApp() {
  return { version };
}
