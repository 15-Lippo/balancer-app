The /pages component directory is for page specific components. i.e. components that only make sense in the context of a single page.

Page specific components should be nested within a folder that has the same name as the page route.
