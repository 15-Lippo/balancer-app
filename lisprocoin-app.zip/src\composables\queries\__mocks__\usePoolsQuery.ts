export default function usePoolsQuery() {
  return {
    data: {},
    isLoading: false,
  };
}
