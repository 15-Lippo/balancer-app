export default function useEthereumTxType() {
  return {
    EthereumTxType: {
      EIP1559: 'EIP1559',
    },
    ethereumTxType: {
      value: 'EIP1559',
    },
  };
}
