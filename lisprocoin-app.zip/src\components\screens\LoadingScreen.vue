<template>
  <div
    class="flex absolute top-0 left-0 z-50 justify-center items-center w-full h-screen bg-gray-50"
  >
    <BalLoadingIcon />
  </div>
</template>
