<script lang="ts" setup>
import VeBalRedirectModal from './VeBalRedirectModal.vue';
</script>

<template>
  <teleport to="#modal">
    <VeBalRedirectModal />
  </teleport>
</template>
