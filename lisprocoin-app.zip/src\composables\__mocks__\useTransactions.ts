export default function useTransactions() {
  return {
    addTransaction: vi.fn(),
  };
}
