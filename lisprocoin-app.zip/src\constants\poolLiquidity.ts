export const LOW_LIQUIDITY_THRESHOLD = 50_000;
export const HIGH_PRICE_IMPACT = 0.01;
export const REKT_PRICE_IMPACT = 0.2;
