import { oneDayInMs } from '@/composables/useTime';

export const WEIGHT_VOTE_DELAY = 10 * oneDayInMs;
