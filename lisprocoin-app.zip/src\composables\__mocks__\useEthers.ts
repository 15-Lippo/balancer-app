export default function useEthers() {
  return {
    txListener: vi.fn(),
  };
}
